suppressMessages(suppressWarnings(library(rlang)))

write_to_log <- function(c, logFileName) {
  write(paste("WARN:", c, sep = " "), file = logFileName, append=TRUE)
}

logWarningsMessages <- function(expr, logFileName) {
  with_handlers(expr, 
                warning = calling(function(cnd){
                            write_to_log(cnd, logFileName)
                            cnd_muffle(cnd)
                          }),
                message = calling(function(cnd){
                            write_to_log(cnd, logFileName)
                            cnd_muffle(cnd)
                          })
                )
}


# x <- function(i){
#   if (i < 1) stop("An error")
#   else if (i < 5) {
#     message("A message")
#     warning("A warning1")
#     warning("A warning2")
#   }
#   else if (i > 10) warning("A warning3")
#   i
# }
# 
# 
# logWarningsMessages(x(14), "log_test.wfl")
# logWarningsMessages(x(4), "log_test.wfl")
# logWarningsMessages(x(-1), "log_test.wfl")


